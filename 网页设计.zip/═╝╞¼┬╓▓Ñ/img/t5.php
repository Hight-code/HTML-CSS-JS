<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />

<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="applicable-device"content="pc,mobile">

<meta name="MSSmartTagsPreventParsing" content="True" />
<meta http-equiv="MSThemeCompatible" content="Yes" />

<link rel="stylesheet" type="text/css" href="/templates/5tu0419/images/head.css" media="screen" />
<style type="text/css">
@import url(forumdata/cache/style_16_common.css?jIr);
</style><script type="text/javascript">var STYLEID = '16', IMGDIR = './images/default', VERHASH = 'jIr', charset = 'gbk', discuz_uid = 0, cookiedomain = '', cookiepath = '/', attackevasive = '0', allowfloatwin = '0', creditnotice = ',,,,,,,', gid = 0, fid = parseInt('30'), tid = parseInt('1418300')</script>
<script src="include/js/common.js?jIr" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="/templates/5tu0419/css/skin.css" />
</head>




<body>
<div id="append_parent"></div><div id="ajaxwaitid"></div>
    <!--���� start-->
    <div class="top"><li><a
href="http://pic.5tu.cn/sucai/zhiliangyue.html" title="2018�������ز�"><img src="http://images.5tu.cn/tj/zhiliangyue.gif"></a><a
href="http://pic.5tu.cn/sucai/saoheichue.html" title="ɨ�ڳ���չ��"><img src="http://images.5tu.cn/tj/saoheizhuanti.gif"></a><a
href="http://pic.5tu.cn/sucai/jieri_guoqinjie.html" title="����69����"><img src="http://images.5tu.cn/tj/guoqing69.gif"></a><a
href="http://pic.5tu.cn/sucai/jieri_zhongqiujie.html" title="2018������ز�"><img src="http://images.5tu.cn/tj/zhongqiu.gif"></a></li></div>
    <!--���� end-->
<!--ͷ�� start-->
<div class="header">
        <!--banner start-->
        <div class="banner">
        	<div class="warp">
<div class="logo"><a href="http://www.5tu.cn"><img src="/templates/5tu0419/images/logo.gif" /></a></div>
        		<form action="http://so.5tu.cn/keyword/" method="get" class="search" target="_blank">
<fieldset>
<legend>��������</legend>
<input type="text" value="" default="�����ľ��������ô�Խ���Խ��" class="search_ipt" focus="empty" name="keyword"/>
<input type="submit" value="����" class="search_submt" />
<div class="search_option">
<strong>�زĸ�ʽ��</strong>
<input type="checkbox" checked="checked" name="kind[]" value="0" /><label class="checkbox">ȫ��</label>
<input type="checkbox" name="kind[]" value="538" /><label class="checkbox">ʸ��ͼ</label>
<input type="checkbox" name="kind[]" value="292" /><label class="checkbox">PSD�ز�</label>
<input type="checkbox" name="kind[]" value="96"/><label class="checkbox">����ͼƬ</label>
<input type="checkbox" name="kind[]" value="2048" /><label class="checkbox">PPT�ز�</label>
<input type="checkbox" name="kind[]" value="4" /><label class="checkbox">PSD</label>
<input type="checkbox" name="kind[]" value="64" /><label class="checkbox">JPG</label>
<input type="checkbox" name="kind[]" value="2" /><label class="checkbox">AI</label>
<input type="checkbox" name="kind[]" value="8" /><label class="checkbox">CDR</label>
<input type="checkbox" name="kind[]" value="16" /><label class="checkbox">EPS</label>
</div>
</fieldset>
</form>
<div class="other">
<div class="upload">
<div class="upload_tit"><em>�ϴ�</em></div>
<ul class="ul_upload">
<li><a href="/usercenter.php?action=upload_list" class="upload1"  target="_blank">�ϴ��ز�</a></li>
<li><a href="/usercenter.php?action=upload_list&amp;status=1" class="upload3" target="_blank">�ҵ��ϴ�</a></li>
</ul>
</div>

<a href="/5tucnzhuce2.php" class="reg">ע��</a>
<div class="login">
<div class="login_tit">��¼</div>
<form class="login_open" action="logging.php?action=login&amp;loginsubmit=yes&amp;floatlogin=yes" name="login" method="post">
<fieldset>
<input type="hidden" name="loginfield" id="loginfield" value="0" />
<input type="hidden" value="4ff0866e" name="formhash">
<legend>��¼����</legend>
<div class="login_close">�ر�</div>
<div class="input"><input type="text" name="username" id="username" value="�û���" class="login_ipt" focus="empty" /></div>
<div class="input"><input type="password" name="password" id="password" value="" class="login_ipt" focus="empty" /></div>
<div class="btn">

<button class="login_submit" tabindex="1" value="true" name="loginsubmit" type="submit">��¼</button>
<a target="_self" href="/qqconnect/index.php?action=login" rel="nofollow" class="open_qq">QQ��¼</a>
</div>
<div class="btn">
<img src="/images/icon_wechat.png" name="btn_wechat_login" id="btn_wechat_login" />
</div>
<div class="login_other">
<label class="fl"><input id="cookietime" type="checkbox" checked="checked" value="2592000" tabindex="1" name="cookietime" /> �Զ���¼</label>
<a title="�һ�����" href="http://www.5tu.cn/logging.php?action=getpasswd">�������룿</a>
<a href="/pm.php" class="fr">���ע��</a>								</div>
</fieldset>
</form>
</div>
<a target="_self" href="/qqconnect/index.php?action=login" rel="nofollow" class="login_qq">QQ��¼</a>
</div>
        	</div>
        </div>
        <!--banner end-->
       <!--���� start-->
        <div class="nav">
        	<div class="warp">
        		<ul class="ul_nav">
        			<li><a href="/">��ҳ</a></li>
        			<li><a href="http://pic.5tu.cn">��ͼչʾ</a></li>
        			<li><a href="http://pic.5tu.cn/sucai/tuku_moban.html">���Դͼ</a></li>
        			<li><a href="http://pic.5tu.cn/psd/index_psd.html">PSDͼ</a></li>
        			<li><a href="http://pic.5tu.cn/vector/index_vector.html">ʸ��ͼ</a></li>
        			<li><a href="http://pic.5tu.cn/photo/index_photo.html">����ͼƬ</a></li>
        			<li><a href="http://pic.5tu.cn/tuku/yuanchuang.html">ԭ����Ʒ</a></li>
        			<li><a href="http://pic.5tu.cn/pptmoban/">PPT</a></li>
        			<li><a href="http://pic.5tu.cn/taobaomoban/">�Ա��ز�</a></li>
        		</ul>
        		<ul class="snav">
        			<li><a href="/doing.php">������</a></li>
        			<li><a href="/memcp.php?action=credits">���طֳ�ֵ</a></li>
        			<li><a href="/help/index.html">���ְ���</a></li>
        		</ul>
        		<form action="http://so.5tu.cn/keyword/" method="get" class="nsearch">
<fieldset>
<legend>��������</legend>
<input type="text" class="nsearch_ipt" value="" focus="empty"  name="keyword" default="����Ҳ������ֱ��"/>
<input type="submit" class="nsearch_submit" value="����" />
</fieldset>
</form>
        	</div>
        </div>
        <!--���� end-->
    </div>
<!--ͷ�� end-->
<div id="wechat_login" class="loginWrap" style="position:absolute;top:50%;left:50%;margin:-300px 0 0 -300px;width:600px;height:500px;border:1px solid #008800;display: none; z-index: 9001;">


<div class="head"><h2 class="tit1">��΢�ŵ�¼��ͼ��</h2><i class="close">�ر�</i></div>

<div  id="wechat_login_container" style="margin-left:150px;">

��΢��ɨ���ά����е�½����,��δ��ʾ,��ˢ��(��F5)��1ҳ������!
</div>

</div>
<script src="templates/5tu0419/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="//res.wx.qq.com/connect/zh_CN/htmledition/js/wxLogin.js" type="text/javascript"></script>
<script type="text/javascript">
var _url = window.document.location + "";
_url = _url.substring(0,_url.indexOf("#"));
var obj = new WxLogin({
id:"wechat_login_container",
appid: "wxf8e564c19c93d796",
scope: "snsapi_login",
redirect_uri: _url,
state: "wechatlogin",
style: "black",
href: ""
});
//�Զ���¼
jQuery(document).ready(function(){
jQuery("#btn_wechat_login").click(function(){
jQuery(this).closest("form").hide().parent().removeClass("login_hover");
jQuery("#wechat_login").slideToggle();

});
jQuery("#wechat_login .close").click(function(){
jQuery("#wechat_login").slideToggle();

});

});
</script>
<div id="nav"><a href="index.php">��ͼ��</a> &raquo; ������ʾ</div>

<div id="wrap" class="wrap s_clear">
<div class="msgfix">
<div class="showmessage">
<h1></h1>
<p><ul class="adtext" style="margin-top:-80px;"><a href="#" id="t11" class="lightlink"><img src="http://www.5tu.cn//templates/5tu0419/images/ksxz.gif"></a> <br><li style="font-size:16px;line-height:2em">�Բ�����û�е�¼��<br>������<a href="#" id="t22"  class="lightlink"><font color=red ><b>���ע��</a></b></font>����<a href="#" id="t111" class="lightlink"><font color=red ><b>��˵�¼</a></b></font>�����ɽ�����������������ء�</font></li></ul><span id="cnzz_stat_icon_1260865997" style="display: none;"></span><script src="http://s95.cnzz.com/stat.php?id=1260865997" type="text/javascript"></script></p>

</div>
</div>
</div>
         <!--��� start-->
<div class="ad2">
<ul>
<script type="text/javascript">
/*ȫվ�ײ����960*90��������2014-7-21*/
var cpro_id = "u1628479";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</ul>		
</div>			
        <!--��� end-->
 
<!--�ײ� start-->
<div class="footer">
    	<div class="warp auto">
            <div class="fl">
                <p class="flink"><a href="http://www.5tu.cn/archiver/" target="_blank">��վ����</a>��|��<a href="/help/sm.html" target="_blank">��������</a>��|��<a href="/help/lx.html" target="_blank">��ϵ����</a>��|�� <script src="http://s111.cnzz.com/stat.php?id=599495&web_id=599495" type="text/javascript" language="JavaScript" charset="gb2312"></script></p>
                <p  class="wzsm"><a href="/" target="_blank">��ͼ��</a> ��ICP��08004085�� @copyright 2005-2014  GMT+8, 2018-9-19 20:15 </p>
            </div>
            <div class="fr">���߰���: <a  target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=77870291&amp;site=qq&amp;menu=yes"><img border="0" SRC='/templates/5tu0419/images/qq.gif' alt="QQ���߷���" ></a></div>
        </div>
</div>
<!--�ײ� end-->
<!--���� start-->
<ul class="fixed">
<li><a href="/memcp.php" class="mycenter" target="_blank">��������</a></li>
<li><a  target="_blank" href="http://wpa.qq.com/msgrd?v=3&amp;uin=77870291&amp;site=qq&amp;menu=yes"  class="online" title="����QQ:77870291">���߽���</a></li>
<li><a href="" class="gotop">�ص�����</a></li>
</ul>
<!--���� end-->
</body>
</html>
<script src="/templates/5tu0419/js/jquery-1.7.1.min.js" type="text/javascript"></script>
<script src="/templates/5tu0419/js/jquery-hcheckbox.js" type="text/javascript"></script>
<script src="/templates/5tu0419/js/index.js" type="text/javascript"></script>
<script src="/templates/5tu0419/js/js.js" type="text/javascript"></script>
 <link rel="stylesheet" type="text/css" href="/templates/5tu0419/css/base.css" />
<link rel="stylesheet" type="text/css" href="/templates/5tu0419/css/skin.css"/>
<link rel="stylesheet" type="text/css" href="/templates/5tu0419/css/style.css" />
<!--��¼-->
<div id="popDiv" class="loginWrap" >


<div class="head"><h2 class="tit1">������QQ��½��΢�ŵ�½���ɣ���</h2><i class="close">�ر�</i></div>

<div class="body">


       <div class="loginPowWindow">
   
      <form id="loginform" action="logging.php?action=login&amp;loginsubmit=yes&amp;floatlogin=yes&amp;inajax=2&amp;cc=2" onsubmit="pwdclear = 1;ajaxpost(this);return false;" name="login" method="post">
  <input type="hidden" value="4ff0866e" name="formhash" />
  <input type="hidden" value="http://www.5tu.cn/recharge.php" name="referer" />
       <div class="hd" style="margin-left:-25px;">
  <a href="/qqconnect/index.php?action=login"><img src="/templates/5tu0419/images/qq-1.png" /></a>
   <img src="/templates/5tu0419/images/wx-1.png" style="margin-left:35px;cursor:pointer;" onClick="jQuery('#popDiv').fadeOut()" name="btn_wechat_login2" id="btn_wechat_login2" />
 
   </div>
        <ul>
          <li>
            <label>�û���</label><input type="text" class="username" name="username" />
          </li>
          <li>
           <label><em style="padding-right:18px;">��</em>��</label><input type="password" class="password" name="password"  /><span id="loginresult"></span>          </li>
        </ul>
        <div class="btns">
          <input type="submit" class="submit" value="�� ¼" />
        </div>
        <p class="p"><span><input id="cookietime" name="cookietime" type="checkbox" class="ck" value="2592000" checked="checked" />�Զ���¼</span><span><a href="javascript:;" onClick="jQuery('#popDiv').fadeOut()" id="t3">��������</a></span><a href="javascript:;" onClick="jQuery('#popDiv').fadeOut()" id="t2">ע�����û�</a></p>
      </form>
    </div>
    <!--login--> 
    </div>

</div>

<!--ע��-->
<div id="popDiv2" class="loginWrap loginWrap2">


<div class="head"><h2 class="tit1">ע�����û�����<strong><a onclick="jQuery('#popDiv2').fadeOut()" id="t4" href="#">��½�����ʺ�</a></strong> </h2><i class="close">�ر�</i></div>


<div class="body">
       <div class="loginPowWindow">
      <form action="http://www.5tu.cn/5tucnzhuce2.php?regsubmit=yes&amp;inajax=2&amp;cc=2" id="form_regist" method="post" onsubmit="registpost(this);return false;">
 	 <input type="hidden" name="formhash" value="4ff0866e" />
       <div class="hd" style="margin-bottom:15px;">
  <a href="/qqconnect/index.php?action=login"><img src="/templates/5tu0419/images/qq_btn3.png" /></a>        </div>
        <ul>
          <li>
            <label>�û���</label><input id="username2" type="text" class="text" name="username" onBlur="checkusername()" /><span id="username2_tip" class="tip"></span>          </li>
          <li>
           <label>����</label><input id="password21" type="password" class="text" name="password"  /><span class="tip"></span>          </li>
           <li>
           <label>ȷ������</label><input id="password22" type="password" class="text" name="password2" onBlur="checkpassword()"  /><span id="password_tip" class="tip">6λ���ϣ����鸴��һЩ</span>          </li>
          <li>
            <label>����</label><input id="email" type="text" class="text" name="email"  onblur="checkemail()"/><span id="email_tip" class="tip">�磺5tu@qq.com</span>          </li>
           <li>
            <label>QQ �� ��</label><input id="newqq" type="text" class="text" name="newqq" /><span class="tip">��Ҫ�����ڻ�ð�������QQ�ſɲ���</span>          </li>
        </ul>
        <div class="btns">
          <input type="submit" class="submit" value="ע ��" /><span><input type="checkbox" class="ck" checked="checked" style="margin-right:5px;" />�����Ķ���ͼ���Ա����</span>        </div>
  
  <div id="regist_successful" class="btns"></div>
      </form>
    </div>
    <!--login--> 
  </div>
</div>

<!--�һ�����-->
<div id="popDiv3" class="loginWrap loginWrap3">


<div class="head"><h2 class="tit1"></h2><i class="close">�ر�</i></div>


<div class="body">
       <div class="loginPowWindow">
      <form action="http://www.5tu.cn/member.php?action=lostpasswd&amp;lostpwsubmit=yes&amp;infloat=yes&amp;inajax=2&amp;cc=2" method="post" onsubmit="findpasswordpost(this);return false;" >
  <input type="hidden" name="formhash" value="4ff0866e" />
<input type="hidden" value="lostpwform" name="handlekey">
       <div class="hd" style="margin-bottom:10px; font-size:14px;">
 �������һ�����        </div>
        <ul>
          <li>
            <label>�û���</label><input id="username3" type="text" class="username" name="username" />
          </li>
          <li>
           <label><em style="padding-right:18px;">��</em>��</label><input id="email3" type="text" class="text"  name="email" /><span id="email_tip3" class="tip"></span>          </li>
        </ul>
        <div class="btns">
          <input type="submit" class="submit2" value="�� ��" /><a href="/qqconnect/index.php?action=login"><img src="/templates/5tu0419/images/qq_btn.png" /></a> <a id="t5" onclick="jQuery('#popDiv3').fadeOut()" href="javascript:;"><img src="/templates/5tu0419/images/qq_btn2.png" /></a>        </div>
        <p class="p2">��δ�ɹ��һأ��ɵ����ϵ���ǡ������ҳ�ײ������߷���</p>
      </form>
    </div>
    <!--login--> 
  </div>
</div>

<script src="/templates/5tu0419/js/jquery.superslide.js" type="text/javascript" type="text/javascript" language="javascript" ></script>
<script src="/templates/5tu0419/js/layer/layer.min.js" type="text/javascript" type="text/javascript" language="javascript" ></script>
<script src="/templates/5tu0419/js/tc.min.js" type="text/javascript" type="text/javascript" language="javascript" ></script>

<script>
function other_pay_ment(){
var pagei = jQuery.layer({
   type: 1,   //0-4��ѡ��,
    title: false,
    border: [0],
    closeBtn: [0],
    shadeClose: true,
    area: ['720px', '455px'],
    page: {dom : '#paylayer'    }
});
//����ر�
jQuery('#pagebtn').click(function(){
    layer.close(pagei);
});
}


function tip_show(obj,msg2)
{
layer.tips(msg2, obj,{
style: ['background-color:#78BA32; color:#fff', '#78BA32'],
    maxWidth:250,
    time: 3,
    closeBtn:[0, true]
});

}

jQuery('.payment ul li input').click(function(){
    jQuery('.msg2').show();
});

jQuery("#demo1").slide({mainCell:".bd ul",autoPlay:true,effect:"topLoop",vis:15,interTime:2000});

function selectPay(id){
var _radio = jQuery('input[type=radio][name="apitype"][value=' + id + ']');
_radio.attr("checked",'checked');
if(id == 'cbpay'){
tip_show(_radio,'֧�ָ��������ͻ��ѳ�ֵ��');
}else if(id == '3'){
tip_show(_radio,'����ͼ���Ա��ٷ����ģ��������ڵ���');
}if(id == '4'){
other_pay_ment();
}
}

jQuery(function(){ 
jQuery('input[type=radio][name="amount"]').click(function(){
jQuery('input[type=radio][name="amount"]').each(function(){
jQuery(this).next('label').css({
  "color":"#6d6d6d"
  });
         	});
jQuery(this).next('label').css({
  "color":"#639700"
  });
});
})

function ajaxpost(dom){
jQuery.ajax({
type: "POST",
url:jQuery(dom).attr('action'),
data:jQuery(dom).serialize(),// ���formid
dataType:"xml",
contentType: "application/x-www-form-urlencoded; charset=utf-8",
error: function(request) {
alert(request);
},
success: function(data) {
//jQuery("#commonLayout_appcreshi").parent().html(data);
//console.log(data);
var html = jQuery(data).find('root').text();
if(html.indexOf("��ӭ������")>=0){
jQuery("#loginresult").text("��½�ɹ�");
//location.reload();
setTimeout(function(){location.reload();},1000);
}else{
//alert(html);
jQuery("#loginresult").text(html);
}
}
});
}

function registpost(dom){

jQuery.ajax({
type: "POST",
url:jQuery(dom).attr('action'),
data:jQuery(dom).serialize(),
dataType:"xml",
contentType: "application/x-www-form-urlencoded;charset=gb2312",
error: function(request) {
alert(request);
},
success: function(data) {
var html = jQuery(data).find('root').text();
if(html.indexOf("�û������������ַ�")>=0){
jQuery("#username2_tip").text("�û������������ַ�").toggleClass("onerror").removeClass("onright");

}

else if(html.indexOf("������������벻һ��")>=0){
jQuery("#password_tip").text("������������벻һ��").toggleClass("onerror").removeClass("onright");
}

else if(html.indexOf("Email�����ַ��ʽ����")>=0){
jQuery("#email_tip").text("Email�����ַ��ʽ����!").toggleClass("onerror").removeClass("onright");
}

else if(html.indexOf("������������벻һ��")>=0){
jQuery("#password_tip").text("������������벻һ��").toggleClass("onerror").removeClass("onright");
}

else if(html.indexOf("���ĵ��Ը�ע���")>=0){
jQuery("#regist_successful").text("���ĵ��Ը�ע������� 1 Сʱ����ʱ������ע��").toggleClass("onerror").removeClass("onright");
}

else if(html.indexOf("���û����Ѿ���ע��")>=0){
jQuery("#username2_tip").text("���û����Ѿ���ע��").toggleClass("onerror").removeClass("onright");
}
else{
jQuery("#regist_successful").text("ע��ɹ�").toggleClass("onright").removeClass("onerror");
setTimeout(function(){location.reload();},1000);
}
}
});
}

function findpasswordpost(dom){

jQuery.ajax({
type: "POST",
url:jQuery(dom).attr('action'),
data:jQuery(dom).serialize(),// ���formid
dataType:"xml",
contentType: "application/x-www-form-urlencoded; charset=utf-8",
error: function(request) {
alert(request);
},
success: function(data) {

var html = jQuery(data).find('root').text();
if(html.indexOf("Email ��ַ��ȫ���ʲ�ƥ��")>=0){
jQuery("#email_tip3").text("�û�����Email ��ַ��ȫ���ʲ�ƥ�䣬���޸ġ�");
}

else if(html.indexOf("ȡ������ķ������͵�����������")>=0){
//alert(html);
//jQuery("#loginresult").text(html);
jQuery("#email_tip3").text("ȡ������ķ������͵����������У����� 3 ��֮�ڵ���̳�޸��������롣");
}


}
});
}

jQuery(document).ready(function(){

jQuery("#t1").click(function(){
popWin("popDiv");
});
jQuery("#t2").click(function(){
popWin("popDiv2"); 
});
jQuery("#t3").click(function(){
popWin("popDiv3"); 
});

jQuery("#t4").click(function(){
popWin("popDiv"); 
});

jQuery("#t11").click(function(){
popWin("popDiv");
});

jQuery("#t111").click(function(){
popWin("popDiv");
});

jQuery("#t22").click(function(){
popWin("popDiv2");
});

jQuery("#t5").click(function(){
popWin("popDiv2"); 
});

jQuery("#btn_wechat_login2").click(function(){
jQuery("#wechat_login").slideToggle();
});
});

var lastusername = lastpassword = lastemail = lastinvitecode = '';
function checkusername() {
//var username = trim(jQuery('username').value);
var _username = jQuery('#username2').val();
if(_username == '' || _username == lastusername) {
return;
} else {
lastusername = _username;
}
var unlen = _username.replace(/[^\x00-\xff]/g, "**").length;
if(unlen < 3 || unlen > 15) {
//messagehandle_register(1, unlen < 3 ? profile_username_tooshort : profile_username_toolong);
jQuery("#username2_tip").text("�û�����Ӧ����3-15֮��.").toggleClass("onerror");
return;
}
//http://www.5tu.cn/ajax.php?infloat=register&handlekey=register&action=checkusername&username=jedece&inajax=1&ajaxtarget=returnmessage4
jQuery.ajax({
             type: "GET",
             url: "http://www.5tu.cn/ajax.php",
 contentType: "application/x-www-form-urlencoded; charset=utf-8",
             data: {
 	username: _username,
infloat:"register",
handlekey:"register",
action:"checkusername",
inajax:"1",
ajaxtarget:"returnmessage4",
cc:"2"
},
             dataType: "xml",
             success: function(data){
var html = jQuery(data).find('root').text();
if(html.indexOf("�û����Ѿ�������ʹ��")>=0){
//�û�����ע��
jQuery("#username2_tip").text("�û����Ѿ�������ʹ��").toggleClass("onerror").removeClass("onright");
}else if(html.indexOf("�û������������ַ�")>=0){
jQuery("#username2_tip").text("�û������������ַ�!").toggleClass("onerror").removeClass("onright");
}else{
jQuery("#username2_tip").text("�û�������!").toggleClass("onright").removeClass("onerror");
}
  }
         });
   // ajaxget('ajax.php?infloat=register&handlekey=register&action=checkusername&username=' + (is_ie && document.charset == 'utf-8' ? encodeURIComponent(username) : username), 'returnmessage4');
}


function checkemail() {
//var username = trim(jQuery('username').value);
var _email = jQuery('#email').val();
if(_email == ''){
jQuery("#email_tip").text("����������!").toggleClass("onerror").removeClass("onright");
}

if(_email == '' || _email == lastemail) {
return;
} else {
lastemail = _email;
}
//http://www.5tu.cn/ajax.php?infloat=register&handlekey=register&action=checkusername&username=jedece&inajax=1&ajaxtarget=returnmessage4
jQuery.ajax({
             type: "GET",
             url: "http://www.5tu.cn/ajax.php",
 contentType: "application/x-www-form-urlencoded; charset=utf-8",
             data: {
handlekey:"register",
nfloat:"register",
action:"checkemail",
inajax:"1",
ajaxtarget:"returnmessage4",
email:_email
},
             dataType: "xml",
             success: function(data){
var html = jQuery(data).find('root').text();
if(html.indexOf("ʹ��")>=0){
//�û�����ע��
jQuery("#email_tip").text("EMAIL�Ѿ�������ʹ��").toggleClass("onerror").removeClass("onright");
}else if(html.indexOf("Email�����ַ��ʽ����")>=0){
jQuery("#email_tip").text("�����ַ��ʽ����!").toggleClass("onerror").removeClass("onright");
}else{
jQuery("#email_tip").text("").removeClass("onerror").removeClass("onright");
}
  }
         });
// http://www.5tu.cn/ajax.php?infloat=register&handlekey=register&action=checkemail&email=jedece@qq.com&inajax=1&ajaxtarget=returnmessage4
   
}


function checkpassword(){
//console.log("checkpassword");
var pass1 = jQuery("#password21").val();
var pass2 = jQuery("#password22").val();

if(!pass1 || !pass2){
jQuery("#password_tip").text("����������.").toggleClass("onerror").removeClass("onright");
}

else if(pass1!=pass2){	
jQuery("#password_tip").text("������������벻һ��.").toggleClass("onerror").removeClass("onright");
}else{
jQuery("#password_tip").text("����У��ͨ��.").toggleClass("onright").removeClass("onerror");
}
}

</script>

